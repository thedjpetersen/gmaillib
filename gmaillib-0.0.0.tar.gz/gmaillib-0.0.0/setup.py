from distutils.core import setup

setup(name='gmaillib',
      version='0.0.0',
      description='Python module for GMail',
      author='David Petersen',
      author_email='davjpetersen@gmail.com',
      url='https://github.com/thedjpetersen/gmaillib',
      py_modules=['gmaillib']
)
